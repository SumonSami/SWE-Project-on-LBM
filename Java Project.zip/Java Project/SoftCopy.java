
package library;


interface SoftCopy {
    public void sizeOfSoftcopy();
    
}
