
package library;

import javax.swing.JOptionPane;
import library.ui.AdminJFrame;


public  class Admin {
   
   private String adminId;
   private String adminName;
   public Admin(String adminId, String adminName){
       this.adminId=adminId;
       this.adminName=adminName;
   }

    public String getAdminId() {
        return adminId;
    }

    public void setAdminId(String adminId) {
        this.adminId = adminId;
    }

    public String getAdminName() {
        return adminName;
    }

    public void setAdminName(String adminName) {
        this.adminName = adminName;
    }
   
    public void work(){
        System.out.println("Manage the library.");
    }
 public void userCheck(String id,String name){
        if (adminId.equals(id) && adminName.equals(name)){
               JOptionPane.showMessageDialog(null, "Successfully Loggdin.");
              AdminJFrame r = new AdminJFrame();
                r.setVisible(true);
        }
         else 
            JOptionPane.showMessageDialog(null, "Sorry. Wrong Username or worng Password.");
                  
             
    
}
}
