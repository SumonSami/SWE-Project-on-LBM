
package library;

import javax.swing.JOptionPane;
import library.ui.BooksJFrame;


public class SportsBook extends Books {
private String writerName;
    public SportsBook(String Id, String Name,String writerName) {
        super(Id,Name);
        this.writerName=writerName;
    }

    public String getWriterName() {
        return writerName;
    }

    public void setWriterName(String writerName) {
        this.writerName = writerName;
    }
    
    public void userCheck(String id,String name,String wname){
        if (bookId.equals(id) && bookName.equals(name) && writerName.equals(wname)){
               JOptionPane.showMessageDialog(null, "Successfully Loggdin.");
              BooksJFrame r = new BooksJFrame();
                r.setVisible(true);
        }
         else 
            JOptionPane.showMessageDialog(null, "Sorry. Something is wrong.");
    }    
}
