
package library;


interface HardCopy {
    public abstract void noOfPages();
    
}
