
package library;

import javax.swing.JOptionPane;
import library.ui.BooksJFrame;


public class StoriesBooks extends Books{
    private String writerName;

    public StoriesBooks(String Id, String Name,String writerName) {
        super(Id, Name);
        this.writerName=writerName;
    }

    public String getWriterName() {
        return writerName;
    }

    public void setWriterName(String writerName) {
        this.writerName = writerName;
    }
    
}
