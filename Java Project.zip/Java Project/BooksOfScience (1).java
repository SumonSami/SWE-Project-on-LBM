
package library;

import javax.swing.JOptionPane;
import library.ui.BooksJFrame;


public class BooksOfScience extends Books{
    private String writerName;

   public BooksOfScience(String bookId,String bookName,String writerName){
        super(bookId,bookName);
        this.writerName=writerName;
    }

  

   

    public String getWriterId() {
        return writerName;
    }

    public void setWriterId(String writerId) {
        this.writerName = writerId;
    }
    
    
    public void subject(){
        System.out.println("All books of Physics.");
       
    }
    public void subject(String englishVersion){
        System.out.println("All books of science in English version.");
       
    }
    public void takingLimit(){
        System.out.println("Anyone can take maximum 3 books at a time.");
        
    }
    
    public void userCheck(String id,String name,String wname){
        if (bookId.equals(id) && bookName.equals(name) && writerName.equals(wname)){
               JOptionPane.showMessageDialog(null, "Successfully Loggdin.");
              BooksJFrame r = new BooksJFrame();
                r.setVisible(true);
        }
         else 
            JOptionPane.showMessageDialog(null, "Sorry. Something is wrong.");
                  
    }
}
