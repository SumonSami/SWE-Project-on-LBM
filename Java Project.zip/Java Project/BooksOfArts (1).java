
package library;

import javax.swing.JOptionPane;
import library.ui.AdminJFrame;
import library.ui.BooksJFrame;

public class BooksOfArts extends Books{
private String writerName;
    public BooksOfArts(String bookId, String bookName,String writerName) {
        super(bookId,bookName);
        this.writerName=writerName;
    }

   

  

    public String getWriterName() {
        return writerName;
    }

    public void setWriterName(String writerName) {
        this.writerName = writerName;
    }
   
    public void userCheck(String id,String name,String wname){
        if (bookId.equals(id) && bookName.equals(name) && writerName.equals(wname)){
               JOptionPane.showMessageDialog(null, "Successfully Loggdin.");
              BooksJFrame r = new BooksJFrame();
                r.setVisible(true);
        }
         else 
            JOptionPane.showMessageDialog(null, "Sorry. Something is wrong.");
                  
             
}

   // public void userCheck(String aaaa, String string, String ab) {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    
}
