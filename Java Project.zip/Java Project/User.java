
package library;

import static com.sun.glass.ui.Cursor.setVisible;
import javax.swing.JOptionPane;
import library.ui.RegisterJFrame;

public class User {
    private String username;
    private String password;
    
   public  User(String userName,String password){
        this.username=userName;
        this.password=password;
    }
    
    public void userCheck(String uname,String pass){
        if (username.equals(uname) && password.equals(pass)){
               JOptionPane.showMessageDialog(null, "Successfully Loggdin.");
               RegisterJFrame r=new RegisterJFrame();
               r.setVisible(true);
               
    }
        else if(username.equals(" ")  && password.equals(" ")){
            JOptionPane.showMessageDialog(null, "Username or Password is empty.");
        }
        
        else 
            JOptionPane.showMessageDialog(null, "Sorry. Wrong Username or worng Password.");
                  
             
    }
    
}
